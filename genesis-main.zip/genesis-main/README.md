# 🔺 Ang Bermuda Airdrop/Testnet 🔺

Ang Owshen ay isang masigla at inobatibong platform sa privacy na binuo para sa mga EVM-based na blockchains. Narito ang mga tagubilin para makilahok sa unang airdrop*** at testnet ng Owshen, na kilala bilang The Bermuda Testnet.

## Kunin ang iyong airdrop!

Bago nagsimula ang aming testnet, nagsasagawa kami ng isang zk-airdrop upang ipamahagi ang unang DIVE tokens sa aming mga gumagamit. Upang makilahok sa airdrop na ito, kailangan mo ng isang Owshen Address. Narito kung paano mo maaaring makakuha ng Owshen Address:
Salamat sa iyong pakikilahok sa The Bermuda Testnet ng Owshen!
Sundan ang mga to para makasali.

1. Buksan ang mo ang iyong mahiwagang Linux Machine sa PC/Laptop.
    WSL or Ubuntu

3. Install ang `libfuse2`:
    ```bash
    sudo apt install libfuse2
    ```
4. IDownload ang latest AppImage of the Owshen Wallet:
    ```bash
    wget https://github.com/OwshenNetwork/owshen/releases/download/v0.1.0/Owshen_v0.1.0_x86_64.AppImage
    ```
5. Gawin itong executable:
   ```bash
    chmod +x Owshen_v0.1.0_x86_64.AppImage
   ```
6. Paandarin ang wallet, Itabi ang iyong 12-WORD MNEMONIC PHRASE sa safe na Lugar.
    ```bash
    ./Owshen_v0.1.0_x86_64.AppImage init
    ```
7. IRun ang Owshen Wallet at iopen ang http://127.0.0.1:9000 sa browser mo.
    ```bash
    ./Owshen_v0.1.0_x86_64.AppImage wallet
    ```
8. ICopy mo yung Owshen Address at ilagay sa comment under ng post! https://x.com/OwshenNetwork/status/1739258666199449979
9. Ang Airdrop ay hanggang ** 31st DECEMBER***. 
Ang mga final na airdrop receivers ay iannounce sa github : https://github.com/OwshenNetwork/genesis
 
Merry Christmas and happy diving! :swimmer: 
